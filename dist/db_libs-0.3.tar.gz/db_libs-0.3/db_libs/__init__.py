# coding=utf8
"""
@author:Administrator
@file: __init__.py
@time: 2020/06
"""

from torndb_for_python3 import Connection as TorndbConnection
